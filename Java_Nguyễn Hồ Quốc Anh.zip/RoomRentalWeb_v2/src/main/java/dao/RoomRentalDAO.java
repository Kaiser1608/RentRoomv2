package dao;
import java.sql.*;
import java.util.ArrayList;
import model.RoomRental;

public class RoomRentalDAO {
    public static Connection connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            return DriverManager.getConnection("jdbc:sqlite:/mnt/data/RoomRentalWeb/database/rental.db");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public static ArrayList<RoomRental> searchRooms(String keyword) {
        ArrayList<RoomRental> list = new ArrayList<>();
        String sql = "SELECT r.id, tenant_name, phone, start_date, method_name, notes " +
                     "FROM room_rental r JOIN payment_method p ON r.payment_method_id = p.id " +
                     "WHERE tenant_name LIKE ? OR phone LIKE ? OR r.id LIKE ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            String like = "%" + (keyword != null ? keyword : "") + "%";
            pstmt.setString(1, like);
            pstmt.setString(2, like);
            pstmt.setString(3, like);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new RoomRental(rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static void insertRoom(String name, String phone, String startDate, int methodId, String notes) {
        String sql = "INSERT INTO room_rental (tenant_name, phone, start_date, payment_method_id, notes) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.setString(3, startDate);
            pstmt.setInt(4, methodId);
            pstmt.setString(5, notes);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void deleteRoom(int id) {
        String sql = "DELETE FROM room_rental WHERE id = ?";
        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
