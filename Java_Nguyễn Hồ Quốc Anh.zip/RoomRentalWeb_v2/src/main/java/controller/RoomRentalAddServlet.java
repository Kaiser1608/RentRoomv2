package controller;
import dao.RoomRentalDAO;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/add")
public class RoomRentalAddServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("tenantName");
        String phone = req.getParameter("phone");
        String startDate = req.getParameter("startDate");
        String method = req.getParameter("paymentMethod");
        String notes = req.getParameter("notes");
        RoomRentalDAO.insertRoom(name, phone, startDate, Integer.parseInt(method), notes);
        resp.sendRedirect("room");
    }
}
