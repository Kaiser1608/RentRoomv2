package controller;
import dao.RoomRentalDAO;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/delete")
public class RoomRentalDeleteServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String idsParam = req.getParameter("ids");
        if (idsParam != null && !idsParam.isEmpty()) {
            String[] ids = idsParam.split(",");
            for (String id : ids) {
                int realId = Integer.parseInt(id.replace("PT-", ""));
                RoomRentalDAO.deleteRoom(realId);
            }
        }
        resp.sendRedirect("room");
    }
}
